# The Social Node
Uma proposta reflexiva e voluntária para reinvestir parte da criação de valor em infraestrutura de bem público de longo prazo por meio de um canal lateral nas blockchains.

## Concepts clés / 主要概念 / Основные идеи / 概要 / Hauptkonzepte / Conceptos clave / Główne założenia / Conceitos-chave
- Reéquilibrage volontaire des flux de valeur
- Mécanisme transparent et optionnel de contribution
- Indépendance vis-à-vis du contrôle politique ou corporatif
- Outils pour le climat, l’éducation, la recherche, l’équité

**Ceci n’est qu’un point de départ.**