# The Social Node
Une proposition réfléchie et volontaire pour réinvestir une partie de la création de valeur dans des infrastructures de bien public à long terme via un canal parallèle sur les blockchains.

## Concepts clés / 主要概念 / Основные идеи / 概要 / Hauptkonzepte / Conceptos clave / Główne założenia / Conceitos-chave
- Reéquilibrage volontaire des flux de valeur
- Mécanisme transparent et optionnel de contribution
- Indépendance vis-à-vis du contrôle politique ou corporatif
- Outils pour le climat, l’éducation, la recherche, l’équité

**Ceci n’est qu’un point de départ.**