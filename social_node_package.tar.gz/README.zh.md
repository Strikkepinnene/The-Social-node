# The Social Node
这是一个反思性、自愿性的提案，旨在通过区块链网络的侧通道将部分价值再投资于长期的公益基础设施。

## Concepts clés / 主要概念 / Основные идеи / 概要 / Hauptkonzepte / Conceptos clave / Główne założenia / Conceitos-chave
- Reéquilibrage volontaire des flux de valeur
- Mécanisme transparent et optionnel de contribution
- Indépendance vis-à-vis du contrôle politique ou corporatif
- Outils pour le climat, l’éducation, la recherche, l’équité

**Ceci n’est qu’un point de départ.**