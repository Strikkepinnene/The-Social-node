# The Social Node
これは、ブロックチェーンネットワーク上のサイドチャネルを利用して価値創造の一部を公共の利益に再投資するための、内省的かつ自発的な提案です。

## Concepts clés / 主要概念 / Основные идеи / 概要 / Hauptkonzepte / Conceptos clave / Główne założenia / Conceitos-chave
- Reéquilibrage volontaire des flux de valeur
- Mécanisme transparent et optionnel de contribution
- Indépendance vis-à-vis du contrôle politique ou corporatif
- Outils pour le climat, l’éducation, la recherche, l’équité

**Ceci n’est qu’un point de départ.**