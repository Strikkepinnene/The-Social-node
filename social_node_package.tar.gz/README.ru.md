# The Social Node
Рефлексивное и добровольное предложение использовать боковой канал в блокчейн-сетях для реинвестирования части созданной стоимости в долгосрочные общественные блага.

## Concepts clés / 主要概念 / Основные идеи / 概要 / Hauptkonzepte / Conceptos clave / Główne założenia / Conceitos-chave
- Reéquilibrage volontaire des flux de valeur
- Mécanisme transparent et optionnel de contribution
- Indépendance vis-à-vis du contrôle politique ou corporatif
- Outils pour le climat, l’éducation, la recherche, l’équité

**Ceci n’est qu’un point de départ.**